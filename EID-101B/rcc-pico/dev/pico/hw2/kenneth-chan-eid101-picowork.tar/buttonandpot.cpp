#include "rcc_stdlib.h"
using namespace std;

 


int main()
{
    void rcc_init_pushbutton()
    {

            gpio_init(RCC_PUSHBUTTON); 
            gpio_pull_up(RCC_PUSHBUTTON); 
            gpio_set_dir(RCC_PUSHBUTTON, false); 
        }

    stdio_init_all();    
    sleep_ms(1500);
    cyw43_arch_init();
    cyw43_arch_gpio_put(0,1); //turns on LED

    rcc_init_pushbutton(); //set up button



    while(true)
    {   



        if(!gpio_get(RCC_PUSHBUTTON)) //if NOT gpio (if gpio is low)
        {
            //do stuff here when button pressed
              cyw43_arch_gpio_put(0,0); 
        }

        else {
            cyw43_arch_gpio_put(0,1); 
        }
    }

 return 0; 
}